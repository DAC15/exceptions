package com.company;

public class CheaterException extends Exception {

    public CheaterException(String message){
        super(message);
    }
}
