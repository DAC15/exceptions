package com.company;

import java.util.Scanner;

public class User  {
    private String name;
    private int coins;
    private int healthPoints;
    private String weapon;
    private int bullets;

    public User(String name, int coins, int healthPoints, String weapon, int bullets) throws CheaterException{
        if(coins>999){
            throw new CheaterException("Can't have more than 999 coins");
        }else{
            this.coins = coins;
        }
        this.name = name;
        if(healthPoints>100){
            throw new CheaterException("Can't have more that 100 heath Points");
        }else{
            this.healthPoints = healthPoints;
        }
        this.weapon = weapon;
        this.bullets = bullets;
    }

    public int getScore(){
        return coins/healthPoints*2;
    }
    public int reload(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the number of bullets");
         bullets= scanner.nextInt();
        System.out.println(bullets + " bullets remaining");
        return bullets;
    }
}
