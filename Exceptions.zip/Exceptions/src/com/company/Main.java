package com.company;


import java.util.InputMismatchException;

public class Main {

    public static void main(String[] args) {
            User user1 = null;
       try {
            user1 = new User("Nick",101, 0, "Ak-47",30);
       }catch (CheaterException e){
           System.out.println(e.getMessage());
       }

       try{
           user1.getScore();
       }catch (ArithmeticException e){
           System.out.println("Can't have 0 health points");
       }


          try {
              user1.reload();
          }catch (InputMismatchException e){
              System.out.println("Enter a valid number");
          }finally {
              try {
                  user1.reload();
              }catch (InputMismatchException e){
                  System.out.println("No more chances to reload");
              }
          }

    }
}
